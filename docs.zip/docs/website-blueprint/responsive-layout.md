# Responsive Layout, Accessibility & SEO Blueprint

## 1. Breakpoint System
| Breakpoint | Target Devices | Layout Behavior |
| :--- | :--- | :--- |
| **Mobile (`< 640px`)** | iPhone, Android Phones | Single column vertical stack, sticky bottom CTA bar, hamburger menu. |
| **Tablet (`640px - 1024px`)** | iPads, Tablets | 2-column feature grids, condensed calculator card, collapsible nav. |
| **Desktop (`1024px - 1440px`)**| Laptops & Desktops | Full 2-column hero split, 4-column feature matrix, expanded ledger preview. |
| **Wide (`> 1440px`)** | Ultra-wide monitors | Max container centered at `1280px` with generous outer margins. |

---

## 2. SEO & OpenGraph Meta Tag Specification
```html
<!-- Primary Meta Tags -->
<title>Rizqly | Islamic ROSCA & Committee Savings Platform</title>
<meta name="title" content="Rizqly | Islamic ROSCA & Committee Savings Platform">
<meta name="description" content="Manage rotating savings committees (Kameti / Chit Funds) with 100% Shariah-compliance, automated WhatsApp receipts, and executive ledger reports.">
<meta name="keywords" content="ROSCA, Islamic savings, Halal finance, Kameti app, Chit Fund management, Zero interest savings, WhatsApp receipts">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://rizqly.app/">
<meta property="og:title" content="Rizqly — Secure & Shariah-Compliant Community Savings">
<meta property="og:description" content="Effortless rotating savings committees with automated WhatsApp receipts and audit statements.">
<meta property="og:image" content="https://rizqly.app/assets/og-banner.png">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:title" content="Rizqly — Islamic ROSCA Platform">
<meta property="twitter:description" content="Zero Riba. Automated WhatsApp receipts. Real-time ledger accounting.">

<!-- Theme Color -->
<meta name="theme-color" content="#064E3B">
```

---

## 3. Web Accessibility (WCAG 2.1 AA Compliance)
* **Contrast Ratios**:
  - Emerald `#064E3B` on White: `9.4:1` (Exceeds AAA standard `7.0:1`).
  - Dark background `#0A0A0A` with Gold `#D4AF37`: `8.6:1` (Exceeds AAA).
* **Keyboard Navigation**:
  - Focus ring: `2px solid #D4AF37` with `offset: 2px` on all interactive buttons, inputs, and accordion toggles.
  - Skip to main content link on header.
* **Screen Reader Semantic HTML**:
  - Proper `<header>`, `<main>`, `<section>`, `<article>`, `<nav>`, and `<footer>` tagging.
  - `aria-expanded` and `aria-controls` on FAQ accordions.
