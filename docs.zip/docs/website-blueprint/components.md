# Rizqly UI Component Catalog & Developer Specifications

## 1. Global Navigation Bar (`Navbar.tsx` / `Navbar.vue`)
```tsx
interface NavbarProps {
  logoUrl?: string;
  theme: 'light' | 'dark';
  onThemeToggle: () => void;
  onLoginClick: () => void;
  onCtaClick: () => void;
}
```
* **Styles**:
  - `height`: `72px`
  - `backdrop-filter`: `blur(16px)`
  - `background`: `rgba(250, 249, 246, 0.85)` (Light) / `rgba(10, 10, 10, 0.85)` (Dark)
  - `border-bottom`: `1px solid rgba(229, 231, 235, 0.8)`

---

## 2. Primary Action Button (`Button.tsx`)
```tsx
interface ButtonProps {
  variant: 'primary' | 'secondary' | 'outline' | 'gold';
  size: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  onClick?: () => void;
  icon?: React.ReactNode;
}
```
* **Variant Specifications**:
  - **`primary`**: `background: #064E3B; color: #FFFFFF; font-weight: 600; border-radius: 10px; hover: #022C22;`
  - **`gold`**: `background: #D4AF37; color: #022C22; font-weight: 700; border-radius: 10px; box-shadow: 0 4px 14px rgba(212,175,55,0.35); hover: #C5A028;`
  - **`outline`**: `background: transparent; color: #064E3B; border: 1.5px solid #064E3B; hover: rgba(6,78,59,0.06);`

---

## 3. Metric Badge & Pill (`Badge.tsx`)
* **Types**:
  - `StatusPaid`: Green text (`#059669`), Light mint bg (`#ECFDF5`), Border (`#A7F3D0`).
  - `StatusPending`: Amber text (`#D97706`), Light amber bg (`#FFFBEB`), Border (`#FDE68A`).
  - `FrequencyWeekly`: Emerald text (`#064E3B`), Light green bg (`#F0FDF4`).
  - `IslamicBadge`: Imperial Gold text (`#D4AF37`), Deep Forest bg (`#064E3B22`).

---

## 4. Interactive ROSCA Calculator Component (`RoscaCalculator.tsx`)
* **State Management**:
  ```ts
  const [contribution, setContribution] = useState<number>(10000);
  const [membersCount, setMembersCount] = useState<number>(10);
  const [frequency, setFrequency] = useState<'Monthly' | 'Weekly'>('Monthly');

  const totalPot = contribution * membersCount;
  const cycleDuration = `${membersCount} ${frequency === 'Monthly' ? 'Months' : 'Weeks'}`;
  ```

---

## 5. WhatsApp Live Simulation Toast (`WhatsAppToast.tsx`)
* **Visual Presentation**:
  - Green WhatsApp check icon (`#25D366`).
  - Header: `"Instant Receipt Broadcast"`.
  - Body: Branded receipt template simulating message delivery to members with timestamp.
