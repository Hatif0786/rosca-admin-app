# Rizqly Website Information Architecture & User Journey

## 1. Information Architecture Map

```text
Rizqly Public Website (https://rizqly.app)
│
├── 1. Global Navigation Bar (Sticky with Blur)
│    ├── Brand Logo (Emerald/Gold Emblem)
│    ├── Features
│    ├── How It Works
│    ├── ROSCA Calculator
│    ├── Shariah & Trust
│    ├── FAQ
│    ├── Theme Toggle (Light/Dark)
│    └── CTAs: [ Admin Login ] [ Start Committee Free ]
│
├── 2. Hero Section
│    ├── Value Headline: Zero-Interest ROSCAs, Full Transparency
│    ├── Automated WhatsApp & Instant Receipt Tag
│    ├── Action Buttons: [ Create Committee ] [ View Interactive Demo ]
│    └── Interactive UI Showcase: Live Dashboard with Real-time Receipts
│
├── 3. Social Proof & Shariah Foundation
│    ├── Barakah Ayah Banner ("لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ")
│    ├── 0% Riba (Zero Interest) / 100% Mutual Aid Philosophy
│    └── Key Stats: (Committees Formed, Pot Volume Managed, Zero Default Rate)
│
├── 4. Feature Matrix (4 Core Capabilities)
│    ├── A. Automated WhatsApp Receipts (Evolution API integration)
│    ├── B. Flexible ROSCA Engine (Weekly/Monthly, Multi-Winner, Onboarding)
│    ├── C. Bait-ul-Maal Live Treasury (Instant Disbursal Alerts)
│    └── D. Executive PDF Statement Generation (Audit-ready records)
│
├── 5. Interactive Pot & Cycle Calculator
│    ├── Real-time calculation of member contributions, duration, & total pot
│    └── Dynamic cycle distribution visualizer
│
├── 6. How It Works (3 Simple Steps)
│    ├── Step 01: Create Group & Define Rules (Fixed or Randomized slots)
│    ├── Step 02: Members Contribute via Instant Payment Tracking
│    └── Step 03: Automated Disbursal & Celebratory Receipt Broadcasts
│
├── 7. Security & Compliance
│    ├── Row-Level Security (Supabase PostgreSQL)
│    ├── End-to-End Encrypted Data Storage
│    └── Multi-Device Access (Web Admin + Mobile App)
│
├── 8. FAQ Accordion (6 Common Questions)
│    ├── What is a ROSCA / Kameti / Chit Fund?
│    ├── Is Rizqly compliant with Islamic finance principles?
│    ├── Can I onboard an existing committee that already started?
│    ├── How do members receive receipts without installing the app?
│    └── How is member data protected?
│
├── 9. High-Conversion Footer CTA
│    ├── "Ready to Bring Barakah & Transparency to Your Savings?"
│    └── [ Launch Admin Dashboard ] [ Download Android APK ]
│
└── 10. Footer
     ├── Brand bio & copyright
     ├── Product, Company, Legal (Privacy, Terms), and Islamic Finance Disclaimer
```

---

## 2. Key User Personas & Conversion Journeys

### Persona A: The Community Leader / Family Elder (Kameti Organizer)
* **Goal**: Wants to eliminate manual handwriting in notebooks, confusion over who paid, and awkward payment chasing.
* **Journey**: Lands on homepage → Sees WhatsApp auto-receipt demo → Uses Calculator to configure family pot → Clicks "Start Committee Free" → Logs into Supabase Web Portal.

### Persona B: Modern Young Professional / Office Group Organizer
* **Goal**: Organize interest-free rotational funding for big milestones (Hajj, Weddings, Gadgets, Cars).
* **Journey**: Views Shariah compliance section → Reviews security & PDF export capabilities → Downloads Android app or signs up on Web.
