# Rizqly — Website Design Blueprint & Design System

Welcome to the **Rizqly** (*رزقلي*) Web Architecture & Design System. This directory provides the complete design, architectural, component, and visual reference documentation for launching the public website for Rizqly — the premier Shariah-compliant ROSCA (Rotating Savings & Credit Association / Kameti / Chit Fund) management platform.

---

## 📁 Directory Structure & Documentation Map

| File | Purpose |
| :--- | :--- |
| **[README.md](file:///c:/Users/HP/.gemini/antigravity/scratch/rosca-admin-app/docs/website-blueprint/README.md)** | Overview, brand philosophy, documentation index (this file). |
| **[design-system.md](file:///c:/Users/HP/.gemini/antigravity/scratch/rosca-admin-app/docs/website-blueprint/design-system.md)** | Complete Figma-style tokens: colors, typography, shadows, elevation, components, spacing. |
| **[information-architecture.md](file:///c:/Users/HP/.gemini/antigravity/scratch/rosca-admin-app/docs/website-blueprint/information-architecture.md)** | Sitemap, user journeys, navigation structure, and conversion funnels. |
| **[pages.md](file:///c:/Users/HP/.gemini/antigravity/scratch/rosca-admin-app/docs/website-blueprint/pages.md)** | Section-by-section breakdown of the landing page, features, calculator, and trust sections. |
| **[components.md](file:///c:/Users/HP/.gemini/antigravity/scratch/rosca-admin-app/docs/website-blueprint/components.md)** | Reusable UI component specs (Navbar, Hero, FeatureCard, RoscaCalculator, LedgerTable, FAQ). |
| **[responsive-layout.md](file:///c:/Users/HP/.gemini/antigravity/scratch/rosca-admin-app/docs/website-blueprint/responsive-layout.md)** | Breakpoints, grid systems, mobile navigation, accessibility, and SEO meta tags. |
| **[index.html](file:///c:/Users/HP/.gemini/antigravity/scratch/rosca-admin-app/docs/website-blueprint/index.html)** | **Interactive Visual Prototype** with live ROSCA pot calculator, dark/light aesthetics, and WhatsApp simulation. |

---

## 🚀 How to View the Interactive Visual Prototype

Open the interactive HTML prototype in any browser:
```powershell
# Open directly in Windows default browser
Start-Process "c:\Users\HP\.gemini\antigravity\scratch\rosca-admin-app\docs\website-blueprint\index.html"
```
Or open the file [`index.html`](file:///c:/Users/HP/.gemini/antigravity/scratch/rosca-admin-app/docs/website-blueprint/index.html) directly from your file manager.

---

## 🏛️ Brand & Product Summary

* **Product**: Rizqly (*رزقلي*)
* **Tagline**: Secure. Transparent. Shariah-Compliant Community Savings.
* **Core Value**: Replaces manual spreadsheets, cash confusion, and awkward payment chasing with automated WhatsApp receipts, scheduled payouts, and real-time ledger accounting for ROSCAs.
