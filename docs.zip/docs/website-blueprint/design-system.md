# Rizqly Design System Specifications

## 1. Color Palette

The color system derives directly from the Rizqly executive mobile application, combining rich Islamic heritage with ultra-modern financial technology aesthetics.

### Primary & Metallic Tones
* **Emerald Forest (Primary Light)**: `#064E3B` — Used for main brand accents, headers, primary buttons, and active states.
* **Deep Night Forest (Primary Dark)**: `#022C22` — Used for gradients, dark backgrounds, and footer surfaces.
* **Imperial Gold (Primary Accent)**: `#D4AF37` — Used for badges, star ratings, CTA borders, highlights, and icons.
* **Amber Shimmer (Secondary Gold)**: `#F59E0B` — Used for interactive hover states and warning callouts.
* **Mint Green (Success & Income)**: `#10B981` — Used for "Paid" badges, positive balances, and confirmation toasts.

### Neutral & Background Scale
* **Alabaster Ivory (Light Background)**: `#FAF9F6` — Warm, premium alternative to stark white.
* **Pure Surface White**: `#FFFFFF` — Card containers and modal dialogs.
* **Border & Outline Light**: `#E5E7EB` / `#D1D5DB` — Clean, subtle card borders.
* **Obsidian Base (Dark Background)**: `#0A0A0A` — Deep dark mode foundation.
* **Charcoal Card (Dark Surface)**: `#121212` / `#1E1E1E` — Elevated dark containers.
* **Slate Text Primary**: `#111827` (Light) / `#FDFCF0` (Dark).
* **Muted Text Secondary**: `#6B7280` (Light) / `#9CA3AF` (Dark).

---

## 2. Typography Hierarchy

### Font Families
* **Display / Brand Serif**: `'Cinzel', 'Playfair Display', Georgia, serif` — Conveys trust, heritage, and distinction.
* **Interface & Financial Sans**: `'Plus Jakarta Sans', 'Inter', -apple-system, sans-serif` — Crystal-clear tabular figures and microcopy.
* **Arabic Calligraphy Font**: `'Amiri', 'Traditional Arabic', serif` — For barakah verses and Islamic motifs.

### Type Scale
| Level | Font Size | Line Height | Weight | Letter Spacing | Use Case |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Hero Display (H1)** | `56px` (`3.5rem`) | `1.1` | `800` (ExtraBold) | `-0.02em` | Main website hero headline |
| **Section Title (H2)** | `36px` (`2.25rem`) | `1.2` | `700` (Bold) | `-0.01em` | Section headers |
| **Card Heading (H3)** | `22px` (`1.375rem`) | `1.3` | `600` (SemiBold) | `0` | Feature cards, Modal titles |
| **Subtitle / Eyebrow** | `13px` (`0.8125rem`) | `1.4` | `700` (Bold) | `+0.12em` | All-caps section taglines |
| **Body Large** | `18px` (`1.125rem`) | `1.6` | `400` (Regular) | `0` | Hero intro paragraphs |
| **Body Default** | `15px` (`0.9375rem`) | `1.5` | `400` / `500` | `0` | Standard UI and descriptions |
| **Tabular Figures** | `16px` / `24px` | `1.0` | `700` (Bold) | `+0.02em` | Currency & metric counters |
| **Micro Caption** | `12px` (`0.75rem`) | `1.3` | `500` (Medium) | `+0.05em` | Timestamps, status pills |

---

## 3. Elevation, Glassmorphism & Shadows

```css
/* Glass Card (Hero Overlay & Dashboard Cards) */
.glass-panel {
  background: rgba(255, 255, 255, 0.85);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border: 1px solid rgba(229, 231, 235, 0.8);
  box-shadow: 0 20px 40px -15px rgba(6, 78, 59, 0.08);
}

/* Dark Glass Panel */
.glass-panel-dark {
  background: rgba(18, 18, 18, 0.75);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(212, 175, 55, 0.15);
  box-shadow: 0 20px 50px -10px rgba(0, 0, 0, 0.6);
}

/* Gold Accent Glow */
.gold-glow {
  box-shadow: 0 0 25px rgba(212, 175, 55, 0.25);
}
```

---

## 4. Spacing System & Grid

* **Base Unit**: `8px`
* **Spacing Scale**: `4px` (xs), `8px` (sm), `16px` (md), `24px` (lg), `32px` (xl), `48px` (2xl), `64px` (3xl), `96px` (4xl)
* **Container Max-Width**: `1280px` (Desktop), `1024px` (Laptop), `768px` (Tablet), `100%` (Mobile)
* **Border Radius**:
  - Buttons / Inputs: `10px`
  - Cards & Panels: `16px`
  - Modal Containers: `24px`
  - Badges / Pills: `9999px` (Full Round)
