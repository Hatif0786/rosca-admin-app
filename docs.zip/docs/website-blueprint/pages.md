# Rizqly Website Page & Section Specifications

## Page: Homepage (`/`)

### Section 1: Top Navigation Bar
* **Position**: Fixed/Sticky (`top: 0`, `z-index: 100`) with glassmorphic backdrop (`backdrop-filter: blur(12px)`).
* **Left**: Gold Geometric Rhombus Logo + `RIZQLY` (Serif, `font-weight: 800`, `color: #064E3B` or `#D4AF37`).
* **Center Navigation**:
  - `Features` (scrolls to `#features`)
  - `Calculator` (scrolls to `#calculator`)
  - `How It Works` (scrolls to `#how-it-works`)
  - `Shariah` (scrolls to `#shariah`)
  - `FAQ` (scrolls to `#faq`)
* **Right Elements**:
  - Theme Toggle Icon (Sun/Moon).
  - Admin Login (Link).
  - Primary CTA Button: `"Start Free"` (Gold background `#D4AF37`, dark text `#022C22`, hover glow).

---

### Section 2: Hero Section
* **Layout**: 2-Column Split (Desktop) / Stacked (Tablet/Mobile).
* **Left Column (Text & Value Prop)**:
  - **Badge Pill**: Emerald green outline with gold text `"✨ ZERO RIBA • 100% TRANSPARENT"`.
  - **H1 Headline**: `"Secure. Shariah-Compliant. Community Savings."` (Font size: `52px`, line-height: `1.15`).
  - **Paragraph**: `"Effortlessly organize, track, and disburse rotating savings committees (ROSCAs). Rizqly automates payment tracking, ledger audits, and instant WhatsApp receipts with zero interest."`
  - **CTA Group**:
    - Primary Gold Button: `"Create Your First Committee"`
    - Secondary Outline Button: `"Explore Live Interactive Demo"`
  - **Trust Metrics Bar**: 4.9★ Community Rating • 0% Hidden Fees • Bank-Grade PostgreSQL Encryption.
* **Right Column (Interactive Product UI Showcase)**:
  - Floating high-fidelity desktop dashboard card showcasing:
    - **Total Pot Metric**: `AED 24,500` / `Rs 500,000` with emerald growth trend.
    - **Active Committees**: 3 groups (Family Fund, Workplace Kameti, Umrah Group).
    - **Live Member Ledger Table**: Showing member avatars, status badges (Paid `Green`, Pending `Amber`), and payout sequence numbers.
    - **Animated WhatsApp Toast Notification**: `"✅ Payment Received! Fatima S. (Rs 10,000) — Instant WhatsApp Receipt Sent via Rizqly"`.

---

### Section 3: Barakah & Shariah Banner
* **Background**: Deep Emerald gradient (`#064E3B` to `#022C22`) with subtle Islamic geometric tessellation.
* **Content**:
  - Arabic Ayah: `« وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ »`
  - Translation & Surah: *"And whoever fears Allah — He will make for him a way out and will provide for him from where he does not expect." (Surah At-Talaq 65:2-3)*.
  - Core Message: 100% Free of Usury (Riba) & Gharar — Mutual cooperative financing as practiced for centuries.

---

### Section 4: Core Feature Matrix
* **4 High-Impact Feature Cards**:
  1. **Automated WhatsApp Receipts**:
     - *Visual*: Simulated WhatsApp chat bubble with custom branded receipt text including Committee Name, Cycle #, and timestamp.
     - *Description*: Send instant payment confirmations directly to members without manual messaging.
  2. **Intelligent Cycle & Payout Scheduler**:
     - *Visual*: Interactive calendar & payout order drag-and-drop slots.
     - *Description*: Configure Weekly or Monthly frequencies, single or multi-pot payouts, and randomize or manually arrange payout order.
  3. **Bait-ul-Maal Live Treasury Dashboard**:
     - *Visual*: Real-time circular progress indicator showing collected funds vs pending target.
     - *Description*: Morning treasury alerts notify you the second enough contributions are collected to disburse the winner's pot.
  4. **One-Click PDF Statement Exports**:
     - *Visual*: Clean A4 financial statement document preview with executive layout.
     - *Description*: Generate audit-ready ledger statements for 1-week, 1-month, 1-year, or all-time with sharing support.

---

### Section 5: Interactive ROSCA Pot Calculator
* **Purpose**: Allows visitors to immediately visualize how their committee will work.
* **User Controls**:
  - *Monthly/Weekly Contribution per Member* (Range slider + numeric input: `Rs 1,000` to `Rs 100,000`).
  - *Total Number of Members* (Stepper / Buttons: `5` to `30`).
  - *Frequency Toggle*: `[ Monthly | Weekly ]`.
* **Dynamic Outputs**:
  - **Total Pot Winner Receives**: `Contribution × Members`
  - **Total Committee Duration**: `X Months / Weeks`
  - **Zero Interest Paid / Saved**: `0% APR (Pure Halal Savings)`

---

### Section 6: How It Works (3 Simple Steps)
* **Step 1: Setup Committee & Members**: Add members with phone numbers, set the contribution amount, and define the payout schedule.
* **Step 2: Collect & Verify with One Tap**: Mark contributions with a single tap in the app. Rizqly generates automated WhatsApp receipts in real-time.
* **Step 3: Disburse Payouts with Barakah**: When the cycle completes, trigger the celebratory payout disbarment and download complete audit statements.

---

### Section 7: FAQ Accordion
* Accordion with 6 collapsible items addressing trust, data safety, WhatsApp setup, and multi-currency support.

---

### Section 8: Final Call To Action
* **Background**: Emerald and Gold radial mesh gradient with floating action card.
* **Headline**: `"Ready to Elevate Your Savings Community?"`
* **Buttons**: `[ Open Web Admin ]` `[ Download Mobile APK ]`
